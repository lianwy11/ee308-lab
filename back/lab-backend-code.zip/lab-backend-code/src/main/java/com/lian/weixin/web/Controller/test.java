package com.lian.weixin.web.Controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.jws.WebParam;
import javax.servlet.http.HttpSession;
import java.util.*;

/**
 * Created with IntelliJ IDEA.
 *
 * @Author: SORA
 * @Date: 2022/04/19/15:33
 * @Description:
 */
@RestController
public class test {

//@RequestMapping("/")
//       public ModelAndView model(){
//    ModelAndView modelAndView=new ModelAndView();
//    modelAndView.setViewName("index");
//return modelAndView;
//
//}

}
